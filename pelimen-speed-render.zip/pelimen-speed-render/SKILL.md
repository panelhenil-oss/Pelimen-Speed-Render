---
name: pelimen-speed-render
description: Build any video (2D, 3D, motion graphics, edits, slideshows) as a complete, ready-to-render project and hand it to the user so their own computer renders it, instead of Claude rendering the full video. Use whenever the user wants a video made and prefers fast local rendering, says "I'll render it on my PC", or when a full render would take Claude a long time.
---

# Pelimen Speed Render

**Claude builds the video. The user's computer renders it.**

Rendering a full video inside Claude's sandbox is slow: it runs on CPU, without a GPU. The user's own computer is usually many times faster. So Claude should spend its time on the part only Claude can do (writing the scenes, the animation, the timing and the audio mix) and send back a project the user can render with **one double-click**.

This skill only covers the workflow: how to prepare, verify, package, deliver and iterate. It has no rules about style, editing or animation. Follow the user's own creative instructions for those.

---

## 1. The workflow at a glance

1. **Understand the request.** Get the script, audio, images, style and length. Ask about the user's computer only if you don't know it yet (see §2).
2. **Pick the engine** (see §3). The default is **Remotion**, because one project covers 2D, 3D, text, audio and captions.
3. **Build the project** in the sandbox. Make it deterministic, keep all assets local and pin all versions (see §4).
4. **Verify cheaply.** Type-check, then render **a handful of still frames at low resolution**. Never render the full video (see §5).
5. **Package it** with one-click render scripts and a short readme in the user's language (see §6).
6. **Deliver.** Either send a ZIP, or write the files straight into a folder the user has connected (see §7).
7. **Iterate.** The user renders, watches and gives feedback. Claude changes only the files that need it and sends them again (see §8).

What the user does: unzip, double-click `render.bat` (or `render.command` / `render.sh`), wait, watch `out/video.mp4`.

---

## 2. Know the target machine (ask once, then remember)

| Question | Why it matters |
|---|---|
| OS (Windows / macOS / Linux) | Which launcher script to ship (`.bat`, `.command`, `.sh`) |
| GPU (e.g. GTX 1660, RTX 3060, Apple M1) | Which OpenGL backend to use for WebGL/3D, and how hard to push quality |
| RAM | How many frames to render in parallel (`--concurrency`) |
| Is Node.js installed? (`node -v`) | Remotion needs Node 18 or newer. If it's missing, tell the user to install the LTS version from nodejs.org |
| Blender / ffmpeg installed? | Only needed if you choose those engines |

Sensible defaults if the user doesn't know:
- Windows with 16 GB RAM, any discrete GPU: `--gl=angle --concurrency=2`.
- 8 GB RAM: `--concurrency=1`.
- macOS (Apple Silicon): `--gl=angle` usually works. Fall back to `--gl=swangle`.

---

## 3. Choose the engine

| Video type | Engine | What the user's PC runs |
|---|---|---|
| Almost anything: 2D animation, motion graphics, captions, slideshows, 3D (three.js / react-three-fiber), data animations | **Remotion** (React + TypeScript) | `npx remotion render` (Chromium + ffmpeg, bundled) |
| Cuts, trims, overlays, music or voice mixing of existing clips | **ffmpeg script** | `ffmpeg` commands in a `.bat` / `.sh` |
| Photoreal 3D, physics, heavy scenes | **Blender** (Python scene script) | `blender -b -P build.py` (Cycles/Eevee on the GPU) |
| Math or technical explainers | **Manim** | `manim -qh scene.py` |

If you're unsure, choose Remotion. The rest of this file uses Remotion as the main example. §9 covers the other engines.

---

## 4. Build rules (so the render on the user's PC matches what Claude tested)

**Determinism.** Every frame must depend only on the frame number.
- Derive all motion from `useCurrentFrame()`. Don't use `Date.now()`, `performance.now()` or real-time animation loops.
- Don't use `Math.random()`. Use a seeded generator, e.g. `mulberry32(seed)`.
- For three.js: render through `@remotion/three`'s `<ThreeCanvas>` and update everything from the frame number. No `useFrame` clocks.

**Everything local, nothing from the internet at render time.**
- Put images, audio, video and fonts in `public/` and load them with `staticFile()`.
- Bundle the font files (`.ttf` / `.woff2`). Load them with `FontFace` inside `delayRender()` / `continueRender()`.
- Preload textures and images before the first frame (`delayRender` until loaded).

**Audio.** Pre-mix the narration, music and sound effects into **one WAV** (`public/mix.wav`) and play it with a single `<Audio>`. This removes timing drift and loudness surprises. Aim for about −14 LUFS and keep true peaks under −1 dBTP.

**Pin versions.** Write exact versions in `package.json` (no `^` or `~`), and include `package-lock.json` when you have it. All `remotion` / `@remotion/*` packages must have **the same version**.

**Composition.** Register one clearly named composition (e.g. `id="Main"`) with the final `width`, `height`, `fps` and `durationInFrames`. Shorts/Reels are 1080×1920, YouTube is 1920×1080, and 30 fps is a safe default.

**Optional props for testing.** Let the composition accept input props like `{ "audio": false }`, so Claude can render silent test stills quickly.

Minimal layout:

```
my-video/
├─ package.json          (pinned versions + "render" script)
├─ package-lock.json
├─ remotion.config.ts    (GPU backend, image format)
├─ tsconfig.json
├─ render.bat            (Windows one-click render)
├─ render.command        (macOS one-click render)   – optional
├─ render.sh             (Linux)                     – optional
├─ preview.bat           (fast half-resolution test render)
├─ HOW_TO_RENDER.txt     (3–5 lines, in the user's language)
├─ public/               (mix.wav, images, fonts, textures)
└─ src/
   ├─ index.ts           (registerRoot)
   ├─ Root.tsx           (<Composition id="Main" …/>)
   └─ Main.tsx           (the video)
```

`remotion.config.ts`:

```ts
import { Config } from "@remotion/cli/config";
Config.setChromiumOpenGlRenderer("angle"); // use the user's GPU for WebGL/3D
Config.setVideoImageFormat("jpeg");
Config.setJpegQuality(95);
```

---

## 5. Verify without rendering the video

Claude's job is to make sure the project **works** and **looks right**, not to produce the final file.

1. **Type-check:** `npx tsc --noEmit`. Fix every error in your own files.
2. **Render 4–10 still frames at half scale**, one or two per scene and at every important moment:
   ```
   npx remotion still src/index.ts Main out/check_0450.png --frame=450 --scale=0.5 --props='{"audio":false}'
   ```
   (In the sandbox you may need `--gl=swangle` because there's no GPU.)
3. **Look at the stills.** Check framing, readability, missing assets, wrong colors and text running off-screen. Fix what's wrong and re-check only those frames.
4. **Check the audio.** The `mix.wav` duration should match `durationInFrames / fps`, and the timings should line up with the narration.
5. **Don't render the full MP4 in the sandbox.** That's exactly the time this workflow saves. If the user explicitly asks for a sandbox render, warn them it will be slow.

Be honest when you hand it over: say that you checked sample frames, not the whole video.

---

## 6. Package it: one-click scripts

### `render.bat` (Windows)

```bat
@echo off
cd /d "%~dp0"
title Rendering video...
where node >nul 2>nul || (echo Node.js is not installed. Get the LTS version from https://nodejs.org & pause & exit /b 1)
if not exist node_modules (
  echo Installing packages - first time only, needs internet...
  call npm install || (echo npm install failed & pause & exit /b 1)
)
if not exist out mkdir out
echo Rendering on your GPU...
call npx remotion render src/index.ts Main out/video.mp4 --gl=angle --concurrency=2 --timeout=240000 --crf=17 --bundle-cache=false
if errorlevel 1 (
  echo GPU mode failed, retrying in software mode - slower...
  call npx remotion render src/index.ts Main out/video.mp4 --gl=swangle --concurrency=2 --timeout=240000 --crf=17 --bundle-cache=false
)
echo.
echo Done: out\video.mp4
pause
```

### `preview.bat` (fast check at half resolution)

```bat
@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Get the LTS version from https://nodejs.org & pause & exit /b 1)
if not exist node_modules (
  echo Installing packages - first time only, needs internet...
  call npm install || (echo npm install failed & pause & exit /b 1)
)
if not exist out mkdir out
call npx remotion render src/index.ts Main out/preview.mp4 --gl=angle --scale=0.5 --concurrency=2 --timeout=240000 --bundle-cache=false
pause
```

### `render.command` (macOS, make it executable with `chmod +x`)

```bash
#!/bin/bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Install Node.js LTS from https://nodejs.org"; read; exit 1; }
[ -d node_modules ] || npm install
mkdir -p out
npx remotion render src/index.ts Main out/video.mp4 --gl=angle --concurrency=2 --timeout=240000 --crf=17 --bundle-cache=false \
 || npx remotion render src/index.ts Main out/video.mp4 --gl=swangle --concurrency=2 --timeout=240000 --crf=17 --bundle-cache=false
echo "Done: out/video.mp4"; read
```

Why these flags:
- `--gl=angle` renders WebGL on the real GPU. That's the big speed-up for 3D and for heavy 2D.
- `--gl=swangle` is the software fallback, so the render still finishes on unusual drivers.
- `--concurrency` sets how many frames render in parallel. Raise it on strong machines and lower it if the PC runs out of memory.
- `--timeout=240000` gives heavy frames and first-time asset loading plenty of time.
- `--bundle-cache=false` makes Remotion always use the latest files. Without it, a re-render after an update can silently produce the **old** video.
- `--crf=17` gives high quality H.264. Use a lower number for better quality and a bigger file.

`HOW_TO_RENDER.txt` (translate it into the user's language):

```
1. Double-click render.bat (the first run installs packages – needs internet, a few minutes).
2. Wait until the window says "Done".
3. Your video is in the "out" folder: out\video.mp4
Quick test first? Double-click preview.bat (half resolution, faster).
If something fails, send Claude the last lines of the black window.
```

---

## 7. Deliver

**Option A: ZIP.** Zip the project **without** `node_modules/` and `out/`, and send it. The user unzips it to a short path without special characters (e.g. `C:\Videos\my-video`) and double-clicks `render.bat`.

**Option B: a connected folder.** If the user has connected a local folder to Claude (e.g. through the Claude desktop app), write the project straight into a sub-folder (`<folder>/<video-name>/`). The user doesn't need to download or unzip anything.

Rules for both:
- **One folder per video.** Never mix projects.
- **Never change files while the user is rendering.** Remotion reads the project when the render starts, so an update in the middle produces the old video. Tell the user to re-run after every update.
- After an update, tell the user exactly which files changed and that they need to run `render.bat` again.
- If the user deletes the folder, re-send the **complete** project, not only the changed files.

---

## 8. Iterate

- The user watches the result and sends notes, screenshots or timestamps ("at 0:12 the text is cut off").
- Claude edits only what's needed and re-checks **only the affected frames** as stills.
- Claude sends the changed files (or the whole project if it's unclear what the user still has) and says: "Run render.bat again."
- If a render fails, ask for the **last 20 lines** of the console window. Common causes:

| Error / symptom | Fix |
|---|---|
| `'node' is not recognized` | Install Node.js LTS and reopen the window |
| `npm install` fails | Check the internet connection. Delete `node_modules` and run again |
| Black frames or WebGL errors | The script already retries with `--gl=swangle`. Update the GPU driver |
| Render stops with a timeout on frame N | Raise `--timeout`. Check that asset preloading resolves |
| Out-of-memory crash or the PC freezes | Lower `--concurrency` to 1 |
| The new render still shows the old video | Make sure `--bundle-cache=false` is set, and don't update files mid-render |
| Fonts look different | Bundle the font in `public/` and load it with `FontFace` |
| Audio out of sync | Use one pre-mixed `mix.wav`, and check its length against `durationInFrames / fps` |

---

## 9. Other engines (same idea, different launcher)

**ffmpeg-only edits.** Deliver the source clips (or tell the user which of their files to place in `input/`), plus a `render.bat` with the full ffmpeg command. Before delivering, test it in the sandbox on a few-second cut (`-t 3`).

```bat
@echo off
cd /d "%~dp0"
ffmpeg -y -i input\clip.mp4 -i public\mix.wav -map 0:v -map 1:a -c:v libx264 -crf 18 -preset medium -c:a aac -b:a 192k -shortest out\video.mp4
pause
```

**Blender.** Deliver `build.py`, which builds the scene, sets the GPU render device, sets the output path, and renders when run as `blender -b -P build.py`. Include `assets/` and a `render.bat` that calls Blender (ask for the install path, or rely on `blender` being on PATH). Before delivering, verify with a single low-sample frame in the sandbox if Blender is available.

**Manim.** Deliver `scene.py` and `render.bat` with `manim -qh scene.py MainScene`. Verify with `-ql` and a single frame (`-s`).

---

## 10. Checklist before sending

- [ ] Composition id, size, fps and duration are final
- [ ] All assets are in `public/` and nothing loads from the internet
- [ ] Animation depends only on the frame number (no clocks, no unseeded random)
- [ ] Versions are pinned, all Remotion packages share the same version, and the lockfile is included
- [ ] `tsc --noEmit` is clean
- [ ] Sample stills at the key moments have been checked
- [ ] Audio length matches the video length
- [ ] `render.bat` / `preview.bat` (and the macOS/Linux scripts if needed) are included
- [ ] `HOW_TO_RENDER.txt` is in the user's language
- [ ] The ZIP has no `node_modules/` or `out/`, or the files went into a fresh sub-folder of the connected folder
- [ ] The message to the user says: what to double-click, where the video appears, and that you checked sample frames only

---

*Note: Remotion is free for individuals and small teams. Larger companies need a Remotion company license, so check remotion.dev/license.*
