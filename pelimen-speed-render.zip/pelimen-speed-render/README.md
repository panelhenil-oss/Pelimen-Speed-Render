# Pelimen Speed Render

**Let Claude build your video. Let your own PC render it.**

When Claude makes an animated video (2D, 3D, motion graphics, captions, edits), the slowest part is usually rendering the final MP4 inside Claude's sandbox, which has no GPU. This skill changes the workflow:

1. Claude writes the complete video project (scenes, animation, timing, audio mix).
2. Claude checks a few still frames, so it knows the project works.
3. Claude sends you the project with a one-click `render.bat`.
4. You double-click it, and your computer renders the video on its own GPU.

That can save a lot of time on every video, and you can iterate faster: Claude changes only the files that need it, and you render again.

## What's inside

- `SKILL.md` contains the instructions for Claude: workflow, build rules, verification, packaging, render scripts (Windows / macOS / Linux), delivery, iteration and troubleshooting. It has no rules about editing or animation style, so it works with any kind of video.

## How to use it

**As a Claude Skill (recommended)**
1. Download this folder (`pelimen-speed-render/`) or the ZIP.
2. Add it to Claude as a skill (upload the ZIP in the Skills section of Claude's settings), or put the folder in your skills directory if you use Claude Code.
3. Ask for a video as usual and add: *"Use Pelimen Speed Render. I'll render it on my PC."*

**As plain instructions**
Paste the contents of `SKILL.md` at the start of your chat, or into a Project's instructions.

## What you need on your computer

- **Node.js 18+** (LTS) from nodejs.org. Needed for Remotion projects (the default).
- Internet the first time you render (to install packages).
- Optional: ffmpeg, Blender or Manim, only if Claude picks one of those engines for your video.

## Rendering

```
1. Unzip the project (or open the folder Claude wrote to).
2. Double-click render.bat   (macOS: render.command)
3. Wait for "Done" → your video is in out/video.mp4
```

Want a quick look first? Run `preview.bat` for a half-resolution test.

## License

MIT. Use it, share it, improve it.

Made by **Pelimen**.
